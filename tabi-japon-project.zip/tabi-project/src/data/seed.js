// ============================================================
// DONNÉES INITIALES — itinéraire Japon 3 semaines
// Ces données sont utilisées au tout premier lancement de l'app, puis
// remplacées par celles synchronisées depuis Supabase / localStorage.
// ============================================================

export const SEED = {
  trip: {
    title: "Japon",
    subtitle: "Trois semaines",
    startDate: "2026-10-12",
    budget: 8500,
    style: ["Culturel", "Foodie", "Nature"],
    pace: "Équilibré",
  },
  cities: [
    { id: "c1", name: "Tokyo",            jp: "東京",   nights: 5, season: "Automne doux, 15-22°C", temp: 19, lat: 35.68, note: "Arrivée — base urbaine, contrastes modernes/traditionnels." },
    { id: "c2", name: "Hakone",           jp: "箱根",   nights: 2, season: "Frais en altitude, 10-17°C", temp: 14, lat: 35.23, note: "Onsen, vue sur le Fuji, art en plein air." },
    { id: "c3", name: "Kyoto",            jp: "京都",   nights: 5, season: "Automne magnifique, 14-23°C", temp: 18, lat: 35.01, note: "Cœur culturel — temples, geishas, jardins." },
    { id: "c4", name: "Nara",             jp: "奈良",   nights: 1, season: "Doux, 14-23°C", temp: 18, lat: 34.69, note: "Excursion — daims sacrés, grand Bouddha." },
    { id: "c5", name: "Osaka",            jp: "大阪",   nights: 3, season: "Doux, 15-24°C", temp: 19, lat: 34.69, note: "Capitale gastronomique, énergie nocturne." },
    { id: "c6", name: "Hiroshima",        jp: "広島",   nights: 2, season: "Doux, 15-23°C", temp: 19, lat: 34.39, note: "Mémoire, paix, et l'île de Miyajima." },
    { id: "c7", name: "Kanazawa",         jp: "金沢",   nights: 2, season: "Frais, 12-20°C", temp: 16, lat: 36.59, note: "Joyau discret — Kenroku-en, quartiers samouraïs." },
  ],
  activities: [
    { id:"a1", cityId:"c1", title:"Senso-ji & Asakusa", cost:0, hours:3, status:"todo", fav:true, note:"Tôt le matin pour éviter la foule." },
    { id:"a2", cityId:"c1", title:"teamLab Planets", cost:55, hours:2, status:"reserved", fav:true, note:"Billet daté obligatoire, réserver en avance." },
    { id:"a3", cityId:"c1", title:"Shibuya Sky", cost:35, hours:1.5, status:"todo", fav:false, note:"Coucher de soleil sur le carrefour." },
    { id:"a4", cityId:"c1", title:"Quartier de Yanaka", cost:0, hours:3, status:"todo", fav:false, note:"Vieux Tokyo, ruelles tranquilles." },
    { id:"a5", cityId:"c3", title:"Fushimi Inari Taisha", cost:0, hours:3, status:"todo", fav:true, note:"Avant 8h pour les torii sans monde." },
    { id:"a6", cityId:"c3", title:"Arashiyama (bambous + Tenryu-ji)", cost:15, hours:4, status:"todo", fav:true, note:"Combiner avec singes d'Iwatayama." },
    { id:"a7", cityId:"c3", title:"Kinkaku-ji (pavillon d'or)", cost:8, hours:1.5, status:"todo", fav:false, note:"" },
    { id:"a8", cityId:"c3", title:"Gion au crépuscule", cost:0, hours:2, status:"todo", fav:false, note:"Respecter les geikos, pas de photos intrusives." },
    { id:"a9", cityId:"c4", title:"Todai-ji & parc aux daims", cost:12, hours:4, status:"todo", fav:true, note:"" },
    { id:"a10", cityId:"c5", title:"Dotonbori la nuit", cost:0, hours:2, status:"todo", fav:true, note:"Street food, néons, Glico." },
    { id:"a11", cityId:"c5", title:"Château d'Osaka", cost:9, hours:2, status:"todo", fav:false, note:"" },
    { id:"a12", cityId:"c6", title:"Mémorial de la Paix", cost:3, hours:3, status:"todo", fav:true, note:"Émotionnellement intense, prévoir du temps." },
    { id:"a13", cityId:"c6", title:"Île de Miyajima (torii flottant)", cost:20, hours:5, status:"todo", fav:true, note:"Vérifier horaire des marées." },
    { id:"a14", cityId:"c2", title:"Hakone Open-Air Museum", cost:18, hours:2.5, status:"todo", fav:false, note:"" },
    { id:"a15", cityId:"c7", title:"Jardin Kenroku-en", cost:8, hours:2, status:"todo", fav:true, note:"Un des trois plus beaux jardins du Japon." },
  ],
  restaurants: [
    { id:"r1", cityId:"c1", name:"Ichiran Shibuya", cuisine:"Ramen tonkotsu", budget:"Économique", avg:14, note:"Box individuelles, parfait solo.", fav:true },
    { id:"r2", cityId:"c1", name:"Sushi Dai (Toyosu)", cuisine:"Sushi", budget:"Moyen", avg:55, note:"Arriver très tôt, file matinale.", fav:true },
    { id:"r3", cityId:"c1", name:"Den", cuisine:"Kaiseki moderne", budget:"Haut de gamme", avg:280, note:"2 étoiles, réserver 1 mois avant.", fav:false },
    { id:"r4", cityId:"c5", name:"Mizuno (okonomiyaki)", cuisine:"Okonomiyaki", budget:"Économique", avg:16, note:"Institution de Dotonbori.", fav:true },
    { id:"r5", cityId:"c5", name:"Kani Doraku", cuisine:"Crabe", budget:"Moyen", avg:60, note:"Le crabe géant animé.", fav:false },
    { id:"r6", cityId:"c3", name:"Kikunoi Roan", cuisine:"Kaiseki", budget:"Haut de gamme", avg:150, note:"Kaiseki accessible d'un grand chef.", fav:true },
    { id:"r7", cityId:"c3", name:"Omen Nippon", cuisine:"Udon", budget:"Économique", avg:18, note:"Près de Gion.", fav:false },
    { id:"r8", cityId:"c6", name:"Okonomi-mura", cuisine:"Okonomiyaki Hiroshima", budget:"Économique", avg:15, note:"Style Hiroshima en couches.", fav:true },
  ],
  stays: [
    { id:"h1", cityId:"c1", name:"Mustard Hotel Shibuya", area:"Shibuya", price:135, dist:"5 min métro", rating:8.7, status:"reserved", note:"Design, central." },
    { id:"h2", cityId:"c2", name:"Hakone Yuryo (ryokan)", area:"Tonosawa", price:240, dist:"navette gare", rating:9.1, status:"todo", note:"Onsen privé, kaiseki inclus." },
    { id:"h3", cityId:"c3", name:"Nazuna Kyoto Tsubaki St.", area:"Higashiyama", price:210, dist:"10 min Gion", rating:9.3, status:"todo", note:"Machiya rénové, bain privé." },
    { id:"h4", cityId:"c5", name:"Hotel Zentis Osaka", area:"Dojima", price:155, dist:"8 min Umeda", rating:9.0, status:"reserved", note:"Vue rivière, super déjeuner." },
    { id:"h5", cityId:"c6", name:"Hotel Granvia Hiroshima", area:"Gare", price:130, dist:"connecté gare", rating:8.6, status:"todo", note:"Pratique pour Miyajima." },
  ],
  expenses: [
    { id:"e1", cat:"Transport", label:"JR Pass 21 jours", amount:610, date:"2026-09-01", paidBy:"Filou", split:"50/50" },
    { id:"e2", cat:"Hébergement", label:"Acompte ryokan Hakone", amount:120, date:"2026-09-10", paidBy:"Kathou", split:"50/50" },
    { id:"e3", cat:"Activités", label:"teamLab Planets x1", amount:55, date:"2026-09-12", paidBy:"Filou", split:"50/50" },
  ],
  checklist: [
    { id:"k1", text:"Vérifier validité passeport (6 mois)", done:true, section:"Avant" },
    { id:"k2", text:"Acheter / activer le JR Pass", done:true, section:"Avant" },
    { id:"k3", text:"Installer Suica sur le téléphone", done:false, section:"Avant" },
    { id:"k4", text:"Assurance voyage", done:false, section:"Avant" },
    { id:"k5", text:"Réserver restaurants étoilés", done:false, section:"Avant" },
    { id:"k6", text:"Pocket WiFi ou eSIM", done:false, section:"Avant" },
    { id:"k7", text:"Adaptateur type A", done:false, section:"Valise" },
    { id:"k8", text:"Chaussures de marche confortables", done:false, section:"Valise" },
    { id:"k9", text:"Veste légère imperméable", done:false, section:"Valise" },
    { id:"k10", text:"Sac pliable pour shopping", done:false, section:"Valise" },
    { id:"k11", text:"Médicaments + ordonnances", done:false, section:"Valise" },
    { id:"k12", text:"Espèces en yens (cash roi au Japon)", done:false, section:"Valise" },
  ],
  notes: [
    { id:"n1", date:"", title:"Inspirations", body:"Le Japon en automne : momiji (érables rouges) à Kyoto vers mi-novembre. Viser les temples tôt le matin." },
  ],
  souvenirs: [
    { id:"s1", text:"Couteau de cuisine (Sakai)", done:false, who:"Moi" },
    { id:"s2", text:"Thé matcha de qualité (Uji)", done:false, who:"Maison" },
    { id:"s3", text:"Kit-Kat saveurs régionales", done:false, who:"Collègues" },
    { id:"s4", text:"Céramique Kiyomizu", done:false, who:"Cadeau" },
  ],
};
